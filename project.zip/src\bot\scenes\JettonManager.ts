﻿// Твой TypeScript код здесь
export const example = "test";
